package com.velocity.mini_project.quize_application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Studentdata  {

	
	public static void studentdataa(String Std_id,String Std_name,String correct_marks,String std_Class) throws SQLException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/qiuzedb","root","ranjeet@8252");
		    
			PreparedStatement stmt = con.prepareStatement("insert into qiuzedb.stusentdata(Std_id,Std_name,correct_marks,std_Class)values(?,?,?,?)");

			stmt.setString(1, "Std_id"); //1 first parameter in query.
			stmt.setString(2, "Std_name");
			stmt.setString(3, "correct_marks");
			stmt.setString(4, "std_Class");
			
			int i=stmt.executeUpdate();                        
					
			System.out.println("Record is inserted."+i);

			con.close();
			stmt.close();

		
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
