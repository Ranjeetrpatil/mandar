package com.velocity.mini_project.quize_application;

public class Student {
	private int Std_id;
	private String Std_name;
	private int correct_marks;
	private String std_Class;
	public int getStd_id() {
		return Std_id;
	}
	public void setStd_id(int std_id) {
		Std_id = std_id;
	}

	
	public int getCorrect_marks() {
		return correct_marks;
	}
	public void setCorrect_marks(int correct_marks) {
		this.correct_marks = correct_marks;
	}
	
	
	
}

