package com.velocity.mini_project.quize_application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


public class Quize_app {
	static int ans; 
	 
	public static void main(String[] args) {
		Student student=new Student();
	
		String Std_name;
		String std_Class=null;
		int count=0;
		
		Scanner sc=new Scanner(System.in);
		{
			System.out.println("Enter Roll number>>");
			int Std_id=sc.nextInt();
			System.out.println("Enter Your name>>");
			 Std_name=sc.next();
			
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/qiuzedb","root","ranjeet@8252");
			
			PreparedStatement ps=con.prepareStatement("select * from qut_ans");
			
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) 
			{
				
				ans=rs.getInt(8);
				System.out.println("");
				System.out.println("Qution_no="+rs.getInt(1));
				
				System.out.println("Q)"+rs.getString(2));
				System.out.print("1="+rs.getString(3));
				System.out.print("  ");
				System.out.print("2="+rs.getString(4));
				System.out.print("  ");
				System.out.print("3="+rs.getString(5));
				System.out.print("  ");
				System.out.print("4="+rs.getString(6));
				System.out.println("  ");
				
				
				
				System.out.println("Enter option ");
				int user=sc.nextInt();
				if(user==ans) {
				     System.out.println("Ans is corect..........!");
				     count++;
				}else {
					System.out.println("Ans is wrong.............!");
				}
					}
			System.out.println("");
			System.out.println("Quiz Successfully Completed.....!");
			System.out.println("");
			System.out.println("YOUER MARKS IS>>>>="+count);
			if(count>=8) {
				System.out.println("Congratulation Your grad Class A");
				
				std_Class="A";
			}if(count>=6&&count<8) {
				System.out.println("Congratulation Your grad Class B");
				
				std_Class="B";
			}if(count>=5&&count<6) {
				System.out.println("Congratulation Your grad Class C");
				std_Class="C";
			}if(count<5) {
				System.out.println("YOU ARE FAIL...bestluk you are next time");
				std_Class="D";
			}
			//***********************************student data****************
			
		    
			int Correct_marks = count;
			
			student.setStd_id(Std_id);
			System.out.println("you are roll no is"+student.getStd_id());
			//student.setStd_name("std_name");
			//System.out.println("student name is"+student.getStd_name());
			student.setCorrect_marks(count);
			System.out.println("stdent marks is "+student.getCorrect_marks());
			//student.setStd_Class(std_Class);
			System.out.println("stdent Class is "+student.getClass());
			PreparedStatement stmt = con.prepareStatement("insert into qiuzedb.stusentdata(Std_id,Std_name,correct_marks,std_Class)values(?,?,?,?)");

			stmt.setInt(1, Std_id);
			stmt.setString(2, Std_name);
			stmt.setInt(3, count);
			stmt.setString(4, std_Class);
			
			int i=stmt.executeUpdate();                        
					
			System.out.println("Record is inserted."+i);

			con.close();
			stmt.close();

		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	}
}
